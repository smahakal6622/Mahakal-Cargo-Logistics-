# Mahakal Cargo Logistics — Cloud integration milestone

This build adds the first browser-to-Supabase application flows. It is **not deployed** and remains inactive until a real Supabase project is configured.

## Files
- `index.html` — responsive public website and booking/login interface.
- `app.js` — Supabase Auth, customer sign-up/sign-in, authenticated booking insert, and public tracking RPC client.
- `config.example.js` — safe browser configuration template. Copy to `config.js` and enter the project URL + publishable/anon key.
- `supabase/migrations/001_initial_schema.sql` — initial operational schema and RLS.
- `supabase/migrations/002_customer_self_provisioning.sql` — automatically creates and links a customer record on customer sign-up.

## Required setup
1. Create a Supabase project under the company's ownership.
2. In SQL Editor, run `001_initial_schema.sql`, then `002_customer_self_provisioning.sql`.
3. Copy `config.example.js` to `config.js`; fill in the Supabase Project URL and publishable/anon key. Never use the `service_role` key in browser code.
4. In Supabase Auth settings, configure the production site URL and allowed redirect URLs. Configure email confirmation and SMTP before customer onboarding.
5. Register the owner account, then promote its profile to admin from the SQL editor using the Auth user UUID. Do not provide admin self-registration.
6. Host the site over HTTPS. Keep `config.js` out of source control if desired; it contains only the publishable key, but project URL/key still identify the project.

## Current functional behavior after setup
- Customer account sign-up and email/password sign-in use Supabase Auth. New sign-ups are provisioned as customers by migration 002.
- Admin/employee sign-in is allowed only when the profile role was granted by an existing trusted admin. The UI does not trust a user-selected role.
- Authenticated customers can submit shipment requests. Database trigger forces customer requests to `pickup_requested` and zeroes financial fields.
- Staff/admin can submit operational bookings. Server trigger generates the docket number.
- Public tracking calls the restricted `track_shipment` SQL function and displays customer-visible events only.

## Not yet implemented / not verified
- No live Supabase project has been connected or tested from this environment. The supplied `config.js` is deliberately blank.
- No domain/hosting deployment or DNS changes have been made.
- Admin operational dashboard actions, staff invitation workflow, rate calculation, invoices/GST PDF, payment reconciliation, ledger posting, POD private storage, complaints, branch/hub scans, driver/trip, salary and expense UI are still pending. Tables/policies in migration 001 are a foundation, not complete workflows.
- No SMS, WhatsApp, OTP, payment gateway or email delivery integration is configured.
- Production security review, database backup, audit triggers, rate limiting, accessibility and end-to-end tests remain required.

## Company details
Mahakal Cargo Logistics · GSTIN 19DTYPD5161B1ZH · Customer Care 01169655510 · mahakalcalcutta@gmail.com · 22A Kali Krishna Tagore Street, Kolkata 700007.
