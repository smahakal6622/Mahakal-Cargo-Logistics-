# Supabase backend setup — Mahakal Cargo Logistics

This folder contains the first database migration for the Mahakal Cargo Logistics website.

## What this migration creates

- Admin / employee / customer profile roles linked to Supabase Auth.
- Branches, customers and shipments.
- Server-generated docket numbers (`MCL-YYYY-0000001`).
- Shipment tracking event history and a restricted public tracking function.
- Pickup requests, rate cards, invoices, payments and expenses.
- Drivers, vehicles, trips, trip shipments and trip expenses.
- Salary records, customer complaints, shipment document metadata and audit logs.
- Row Level Security policies to separate customer data from staff/admin operations.

## Apply to a new Supabase project

1. Create a Supabase project.
2. Open **SQL Editor** in the Supabase dashboard.
3. Run `migrations/001_initial_schema.sql`.
4. Register the business owner's account through Supabase Auth.
5. In SQL Editor, promote that account to admin using its Auth user UUID:

   ```sql
   update public.profiles
   set role = 'admin'
   where id = '<AUTH_USER_UUID>';
   ```

6. Add employees through a trusted server-side Admin workflow. Do not allow a browser user to edit their own role.
7. Configure private Storage buckets and separate Storage RLS policies for POD, docket, invoice and receipt files.
8. Add the Supabase project URL and **publishable/anon key** to the frontend environment. Keep the `service_role` key server-side only.

## Important implementation notes

- This is the initial schema foundation, not a complete deployed backend.
- Public tracking intentionally returns only docket, route, status and customer-visible scan events. It does not expose sender/receiver phone numbers or street addresses.
- A booking created by a customer must be associated with that customer's `customers.id` in `profiles.customer_id`.
- Customer-visible booking and tracking data is protected by Row Level Security.
- Invoice numbering, GST place-of-supply logic, rate selection, ledger posting, payment reconciliation, PDF generation, OTP, notifications and audit triggers still need server-side implementation and tests before production use.
- Review policies and run security tests in a non-production project before connecting real customer data.

## Company details configured in the website

- Mahakal Cargo Logistics
- 22A Kali Krishna Tagore Street, Kolkata 700007
- GSTIN: 19DTYPD5161B1ZH
- Customer care: 01169655510
- Email: mahakalcalcutta@gmail.com
- Website: mahakalcargo.com
