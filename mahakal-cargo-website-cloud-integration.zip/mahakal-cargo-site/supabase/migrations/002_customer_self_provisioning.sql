-- Mahakal Cargo Logistics — customer self-provisioning and public tracking hardening
-- Apply after 001_initial_schema.sql. New signups receive a customer row linked to their profile.

create or replace function public.handle_new_auth_user()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_customer_id uuid;
  v_name text;
  v_mobile text;
begin
  v_name := coalesce(nullif(trim(new.raw_user_meta_data->>'full_name'), ''), split_part(coalesce(new.email, 'Customer'), '@', 1));
  v_mobile := nullif(trim(new.raw_user_meta_data->>'mobile'), '');

  insert into public.profiles (id, full_name, mobile, role)
  values (new.id, v_name, v_mobile, 'customer')
  on conflict (id) do update set
    full_name = excluded.full_name,
    mobile = coalesce(public.profiles.mobile, excluded.mobile);

  insert into public.customers (auth_user_id, legal_name, contact_name, email, mobile)
  values (new.id, v_name, v_name, new.email, v_mobile)
  on conflict (auth_user_id) do update set
    email = excluded.email,
    mobile = coalesce(public.customers.mobile, excluded.mobile)
  returning id into v_customer_id;

  update public.profiles set customer_id = v_customer_id where id = new.id;
  return new;
end;
$$;

-- Replace the auth trigger function in place; the existing on_auth_user_created trigger remains attached.
-- Customer bookings can now satisfy shipments_create_own_or_staff because customer_id is provisioned.

-- Tracking is intentionally public but returns only route/status/customer-visible scan data.
revoke all on function public.track_shipment(text) from public;
grant execute on function public.track_shipment(text) to anon, authenticated;
