-- Mahakal Cargo Logistics: Supabase/PostgreSQL foundation
-- Apply in a new Supabase project using the SQL editor or Supabase CLI.
-- SECURITY: never expose the service_role key in browser/mobile code.

create extension if not exists pgcrypto;

create type public.app_role as enum ('admin', 'employee', 'customer');
create type public.shipment_status as enum (
  'booking_confirmed', 'pickup_requested', 'picked_up', 'received_at_origin_hub',
  'dispatched', 'in_transit', 'reached_destination_hub', 'out_for_delivery',
  'delivered', 'delivery_failed', 'return_to_origin', 'cancelled'
);
create type public.payment_status as enum ('unpaid', 'part_paid', 'paid', 'to_pay', 'credit', 'refunded');
create type public.payment_mode as enum ('cash', 'bank', 'upi', 'card', 'other');

create sequence if not exists public.docket_number_seq;

create table public.branches (
  id uuid primary key default gen_random_uuid(),
  branch_code text not null unique,
  name text not null,
  address text,
  city text,
  state text,
  pincode text,
  phone text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.customers (
  id uuid primary key default gen_random_uuid(),
  auth_user_id uuid unique references auth.users(id) on delete set null,
  customer_code text unique,
  legal_name text not null,
  contact_name text,
  email text,
  mobile text,
  gstin text,
  billing_address text,
  billing_city text,
  billing_state text,
  billing_pincode text,
  credit_limit numeric(14,2) not null default 0 check (credit_limit >= 0),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  mobile text,
  role public.app_role not null default 'customer',
  customer_id uuid references public.customers(id) on delete set null,
  branch_id uuid references public.branches(id) on delete set null,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.shipments (
  id uuid primary key default gen_random_uuid(),
  docket_no text not null unique,
  booking_date date not null default current_date,
  created_by uuid not null references auth.users(id),
  customer_id uuid references public.customers(id),
  origin_branch_id uuid references public.branches(id),
  destination_branch_id uuid references public.branches(id),
  sender_name text not null,
  sender_mobile text,
  sender_address text,
  sender_city text not null,
  sender_state text,
  sender_pincode text,
  receiver_name text not null,
  receiver_mobile text,
  receiver_address text,
  receiver_city text not null,
  receiver_state text,
  receiver_pincode text,
  service_type text not null check (service_type in ('road','air','railway','ptl','ftl','door_to_door','courier','international','packers_movers','other')),
  package_count integer not null default 1 check (package_count > 0),
  actual_weight_kg numeric(12,3) not null default 0 check (actual_weight_kg >= 0),
  volumetric_weight_kg numeric(12,3) not null default 0 check (volumetric_weight_kg >= 0),
  chargeable_weight_kg numeric(12,3) not null default 0 check (chargeable_weight_kg >= 0),
  freight_amount numeric(14,2) not null default 0 check (freight_amount >= 0),
  handling_amount numeric(14,2) not null default 0 check (handling_amount >= 0),
  insurance_amount numeric(14,2) not null default 0 check (insurance_amount >= 0),
  other_charges numeric(14,2) not null default 0 check (other_charges >= 0),
  gst_rate numeric(5,2) not null default 18 check (gst_rate >= 0 and gst_rate <= 100),
  gst_amount numeric(14,2) not null default 0 check (gst_amount >= 0),
  grand_total numeric(14,2) not null default 0 check (grand_total >= 0),
  payment_type public.payment_status not null default 'unpaid',
  status public.shipment_status not null default 'booking_confirmed',
  goods_description text,
  internal_notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.tracking_events (
  id uuid primary key default gen_random_uuid(),
  shipment_id uuid not null references public.shipments(id) on delete cascade,
  status public.shipment_status not null,
  location text,
  remarks text,
  event_time timestamptz not null default now(),
  created_by uuid references auth.users(id),
  is_customer_visible boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.pickup_requests (
  id uuid primary key default gen_random_uuid(),
  request_no text not null unique default ('PICK-' || upper(substr(replace(gen_random_uuid()::text,'-',''),1,10))),
  customer_id uuid references public.customers(id),
  created_by uuid not null references auth.users(id),
  pickup_name text not null,
  pickup_mobile text not null,
  pickup_address text not null,
  pickup_city text not null,
  pickup_pincode text,
  preferred_date date,
  package_count integer not null default 1 check (package_count > 0),
  approximate_weight_kg numeric(12,3) check (approximate_weight_kg is null or approximate_weight_kg >= 0),
  notes text,
  status text not null default 'requested' check (status in ('requested','assigned','picked_up','completed','cancelled')),
  created_at timestamptz not null default now()
);

create table public.rate_cards (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  service_type text not null,
  origin_region text,
  destination_region text,
  origin_pincode_prefix text,
  destination_pincode_prefix text,
  min_weight_kg numeric(12,3) not null default 0,
  max_weight_kg numeric(12,3),
  rate_per_kg numeric(14,2) not null default 0,
  minimum_charge numeric(14,2) not null default 0,
  handling_per_kg numeric(14,2) not null default 0,
  insurance_rate numeric(7,4) not null default 0.4,
  gst_rate numeric(5,2) not null default 18,
  effective_from date not null default current_date,
  effective_to date,
  customer_id uuid references public.customers(id),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  check (max_weight_kg is null or max_weight_kg >= min_weight_kg)
);

create table public.invoices (
  id uuid primary key default gen_random_uuid(),
  invoice_no text not null unique,
  customer_id uuid not null references public.customers(id),
  shipment_id uuid references public.shipments(id),
  invoice_date date not null default current_date,
  due_date date,
  taxable_amount numeric(14,2) not null default 0,
  cgst_amount numeric(14,2) not null default 0,
  sgst_amount numeric(14,2) not null default 0,
  igst_amount numeric(14,2) not null default 0,
  total_amount numeric(14,2) not null default 0,
  amount_paid numeric(14,2) not null default 0,
  status text not null default 'draft' check (status in ('draft','issued','part_paid','paid','cancelled')),
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table public.payments (
  id uuid primary key default gen_random_uuid(),
  receipt_no text not null unique,
  customer_id uuid references public.customers(id),
  invoice_id uuid references public.invoices(id),
  shipment_id uuid references public.shipments(id),
  amount numeric(14,2) not null check (amount > 0),
  mode public.payment_mode not null,
  reference_no text,
  paid_at timestamptz not null default now(),
  notes text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table public.expenses (
  id uuid primary key default gen_random_uuid(),
  expense_date date not null default current_date,
  category text not null,
  amount numeric(14,2) not null check (amount > 0),
  payment_mode public.payment_mode not null default 'cash',
  branch_id uuid references public.branches(id),
  shipment_id uuid references public.shipments(id),
  description text,
  receipt_path text,
  approval_status text not null default 'pending' check (approval_status in ('pending','approved','rejected')),
  added_by uuid not null references auth.users(id),
  approved_by uuid references auth.users(id),
  approved_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.drivers (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  mobile text not null,
  address text,
  id_document_path text,
  joining_date date,
  monthly_salary numeric(14,2) not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.vehicles (
  id uuid primary key default gen_random_uuid(),
  registration_no text not null unique,
  vehicle_type text,
  capacity_kg numeric(12,2),
  insurance_expiry date,
  fitness_expiry date,
  permit_expiry date,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.trips (
  id uuid primary key default gen_random_uuid(),
  trip_no text not null unique,
  driver_id uuid references public.drivers(id),
  vehicle_id uuid references public.vehicles(id),
  origin text not null,
  destination text not null,
  start_at timestamptz,
  expected_delivery_at timestamptz,
  completed_at timestamptz,
  start_km numeric(12,2),
  end_km numeric(12,2),
  driver_advance numeric(14,2) not null default 0,
  status text not null default 'assigned' check (status in ('assigned','started','in_transit','delivered','completed','cancelled')),
  notes text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  check (end_km is null or start_km is null or end_km >= start_km)
);

create table public.trip_shipments (
  trip_id uuid not null references public.trips(id) on delete cascade,
  shipment_id uuid not null references public.shipments(id) on delete restrict,
  primary key (trip_id, shipment_id)
);

create table public.trip_expenses (
  id uuid primary key default gen_random_uuid(),
  trip_id uuid not null references public.trips(id) on delete cascade,
  category text not null,
  amount numeric(14,2) not null check (amount >= 0),
  receipt_path text,
  notes text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table public.salary_records (
  id uuid primary key default gen_random_uuid(),
  employee_user_id uuid references auth.users(id),
  driver_id uuid references public.drivers(id),
  salary_month date not null,
  basic_salary numeric(14,2) not null default 0,
  bonus numeric(14,2) not null default 0,
  overtime numeric(14,2) not null default 0,
  advance_deduction numeric(14,2) not null default 0,
  other_deductions numeric(14,2) not null default 0,
  net_salary numeric(14,2) generated always as (basic_salary + bonus + overtime - advance_deduction - other_deductions) stored,
  paid_amount numeric(14,2) not null default 0,
  paid_at timestamptz,
  payment_mode public.payment_mode,
  notes text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  check ((employee_user_id is not null) <> (driver_id is not null)),
  unique (employee_user_id, salary_month),
  unique (driver_id, salary_month)
);

create table public.complaints (
  id uuid primary key default gen_random_uuid(),
  ticket_no text not null unique default ('MCL-TKT-' || upper(substr(replace(gen_random_uuid()::text,'-',''),1,10))),
  customer_id uuid references public.customers(id),
  shipment_id uuid references public.shipments(id),
  created_by uuid not null references auth.users(id),
  subject text not null,
  description text not null,
  status text not null default 'open' check (status in ('open','in_progress','resolved','closed')),
  assigned_to uuid references auth.users(id),
  resolution text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.shipment_documents (
  id uuid primary key default gen_random_uuid(),
  shipment_id uuid not null references public.shipments(id) on delete cascade,
  document_type text not null check (document_type in ('docket','invoice','pod','eway_bill','other')),
  storage_path text not null,
  uploaded_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table public.audit_logs (
  id bigint generated always as identity primary key,
  actor_id uuid references auth.users(id),
  action text not null,
  table_name text not null,
  record_id text,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

-- Docket numbers are generated server-side, not by a browser counter.
create or replace function public.assign_docket_number()
returns trigger language plpgsql set search_path = public, pg_temp as $$
begin
  if new.docket_no is null or btrim(new.docket_no) = '' then
    new.docket_no := 'MCL-' || to_char(coalesce(new.booking_date, current_date), 'YYYY') || '-' || lpad(nextval('public.docket_number_seq')::text, 7, '0');
  end if;
  return new;
end; $$;
create trigger shipments_assign_docket before insert on public.shipments
for each row execute function public.assign_docket_number();

-- Customer portal bookings are requests, not self-approved financial shipments.
-- Staff/Admin can enter approved operational and financial values.
create or replace function public.guard_customer_shipment_insert()
returns trigger language plpgsql security definer set search_path = public, pg_temp as $$
begin
  if auth.uid() is not null and not public.is_staff_or_admin() then
    new.created_by := auth.uid();
    new.status := 'pickup_requested';
    new.payment_type := 'unpaid';
    new.freight_amount := 0;
    new.handling_amount := 0;
    new.insurance_amount := 0;
    new.other_charges := 0;
    new.gst_amount := 0;
    new.grand_total := 0;
  end if;
  return new;
end; $$;
create trigger shipments_guard_customer_insert before insert on public.shipments
for each row execute function public.guard_customer_shipment_insert();

create or replace function public.touch_updated_at()
returns trigger language plpgsql set search_path = public, pg_temp as $$
begin new.updated_at = now(); return new; end; $$;
create trigger customers_touch before update on public.customers for each row execute function public.touch_updated_at();
create trigger profiles_touch before update on public.profiles for each row execute function public.touch_updated_at();
create trigger shipments_touch before update on public.shipments for each row execute function public.touch_updated_at();
create trigger complaints_touch before update on public.complaints for each row execute function public.touch_updated_at();

-- Create a basic profile for each newly registered auth user. New accounts default to customer.
create or replace function public.handle_new_auth_user()
returns trigger language plpgsql security definer set search_path = public, pg_temp as $$
begin
  insert into public.profiles (id, full_name, role)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''), 'customer')
  on conflict (id) do nothing;
  return new;
end; $$;
create trigger on_auth_user_created after insert on auth.users
for each row execute function public.handle_new_auth_user();

-- Helper functions avoid recursive profile RLS policies. Role changes must be done by trusted Admin tooling.
create or replace function public.current_app_role()
returns public.app_role language sql stable security definer set search_path = public, pg_temp as $$
  select role from public.profiles where id = auth.uid() and is_active = true limit 1;
$$;
create or replace function public.is_staff_or_admin()
returns boolean language sql stable security definer set search_path = public, pg_temp as $$
  select coalesce(public.current_app_role() in ('admin','employee'), false);
$$;
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public, pg_temp as $$
  select coalesce(public.current_app_role() = 'admin', false);
$$;
create or replace function public.my_customer_id()
returns uuid language sql stable security definer set search_path = public, pg_temp as $$
  select customer_id from public.profiles where id = auth.uid() and is_active = true limit 1;
$$;

-- Restricted public tracking lookup: exposes only shipment route/status and customer-visible scans.
create or replace function public.track_shipment(p_docket_no text)
returns table (
  docket_no text,
  booking_date date,
  origin_city text,
  destination_city text,
  current_status public.shipment_status,
  last_updated timestamptz,
  events jsonb
)
language sql stable security definer set search_path = public, pg_temp as $$
  select s.docket_no, s.booking_date, s.sender_city, s.receiver_city, s.status, s.updated_at,
    coalesce((select jsonb_agg(jsonb_build_object(
      'status', e.status, 'location', e.location, 'remarks', e.remarks, 'event_time', e.event_time
    ) order by e.event_time asc)
    from public.tracking_events e where e.shipment_id = s.id and e.is_customer_visible = true), '[]'::jsonb)
  from public.shipments s
  where s.docket_no = upper(trim(p_docket_no))
  limit 1;
$$;
grant execute on function public.track_shipment(text) to anon, authenticated;

create index shipments_customer_idx on public.shipments(customer_id, booking_date desc);
create index shipments_status_idx on public.shipments(status, booking_date desc);
create index shipments_docket_idx on public.shipments(docket_no);
create index tracking_events_shipment_time_idx on public.tracking_events(shipment_id, event_time);
create index invoices_customer_date_idx on public.invoices(customer_id, invoice_date desc);
create index expenses_date_category_idx on public.expenses(expense_date desc, category);
create index trips_status_idx on public.trips(status, start_at desc);
create index complaints_customer_idx on public.complaints(customer_id, created_at desc);

-- Enable row-level security on every application table.
alter table public.branches enable row level security;
alter table public.customers enable row level security;
alter table public.profiles enable row level security;
alter table public.shipments enable row level security;
alter table public.tracking_events enable row level security;
alter table public.pickup_requests enable row level security;
alter table public.rate_cards enable row level security;
alter table public.invoices enable row level security;
alter table public.payments enable row level security;
alter table public.expenses enable row level security;
alter table public.drivers enable row level security;
alter table public.vehicles enable row level security;
alter table public.trips enable row level security;
alter table public.trip_shipments enable row level security;
alter table public.trip_expenses enable row level security;
alter table public.salary_records enable row level security;
alter table public.complaints enable row level security;
alter table public.shipment_documents enable row level security;
alter table public.audit_logs enable row level security;

-- Profiles: users can read/update only their own non-privilege fields; staff can read all.
create policy profiles_read_self_or_staff on public.profiles for select to authenticated
using (id = auth.uid() or public.is_staff_or_admin());
create policy profiles_update_self on public.profiles for update to authenticated
using (id = auth.uid()) with check (id = auth.uid());
-- Restrict self-service profile edits to harmless fields; role/customer/branch/active flags
-- are changed only by trusted server-side Admin tooling or the SQL dashboard.
revoke update on public.profiles from authenticated;
grant update (full_name, mobile) on public.profiles to authenticated;
create policy profiles_admin_all on public.profiles for all to authenticated
using (public.is_admin()) with check (public.is_admin());

create policy branches_read_authenticated on public.branches for select to authenticated using (true);
create policy branches_admin_manage on public.branches for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy customers_read_own_or_staff on public.customers for select to authenticated
using (auth_user_id = auth.uid() or public.is_staff_or_admin());
create policy customers_staff_manage on public.customers for all to authenticated
using (public.is_staff_or_admin()) with check (public.is_staff_or_admin());

create policy shipments_read_own_or_staff on public.shipments for select to authenticated
using (public.is_staff_or_admin() or customer_id = public.my_customer_id());
create policy shipments_create_own_or_staff on public.shipments for insert to authenticated
with check (created_by = auth.uid() and (public.is_staff_or_admin() or customer_id = public.my_customer_id()));
create policy shipments_staff_update on public.shipments for update to authenticated
using (public.is_staff_or_admin()) with check (public.is_staff_or_admin());
create policy shipments_admin_delete on public.shipments for delete to authenticated using (public.is_admin());

create policy tracking_read_own_or_staff on public.tracking_events for select to authenticated
using (public.is_staff_or_admin() or exists (select 1 from public.shipments s where s.id = shipment_id and s.customer_id = public.my_customer_id()));
create policy tracking_staff_insert on public.tracking_events for insert to authenticated
with check (public.is_staff_or_admin() and created_by = auth.uid());
create policy tracking_admin_manage on public.tracking_events for all to authenticated
using (public.is_admin()) with check (public.is_admin());

create policy pickup_read_own_or_staff on public.pickup_requests for select to authenticated
using (public.is_staff_or_admin() or customer_id = public.my_customer_id());
create policy pickup_create_own on public.pickup_requests for insert to authenticated
with check (created_by = auth.uid() and (public.is_staff_or_admin() or customer_id = public.my_customer_id()));
create policy pickup_staff_update on public.pickup_requests for update to authenticated
using (public.is_staff_or_admin()) with check (public.is_staff_or_admin());

create policy rates_read_authenticated on public.rate_cards for select to authenticated using (is_active = true or public.is_staff_or_admin());
create policy rates_admin_manage on public.rate_cards for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy invoices_read_own_or_staff on public.invoices for select to authenticated
using (public.is_staff_or_admin() or customer_id = public.my_customer_id());
create policy invoices_staff_manage on public.invoices for all to authenticated
using (public.is_staff_or_admin()) with check (public.is_staff_or_admin());
create policy payments_read_own_or_staff on public.payments for select to authenticated
using (public.is_staff_or_admin() or customer_id = public.my_customer_id());
create policy payments_staff_manage on public.payments for all to authenticated
using (public.is_staff_or_admin()) with check (public.is_staff_or_admin());

create policy expenses_staff_read on public.expenses for select to authenticated using (public.is_staff_or_admin());
create policy expenses_staff_add on public.expenses for insert to authenticated with check (added_by = auth.uid() and public.is_staff_or_admin());
create policy expenses_admin_manage on public.expenses for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy drivers_staff_read on public.drivers for select to authenticated using (public.is_staff_or_admin());
create policy drivers_admin_manage on public.drivers for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy vehicles_staff_read on public.vehicles for select to authenticated using (public.is_staff_or_admin());
create policy vehicles_admin_manage on public.vehicles for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy trips_staff_all on public.trips for all to authenticated using (public.is_staff_or_admin()) with check (public.is_staff_or_admin());
create policy trip_shipments_staff_all on public.trip_shipments for all to authenticated using (public.is_staff_or_admin()) with check (public.is_staff_or_admin());
create policy trip_expenses_staff_all on public.trip_expenses for all to authenticated using (public.is_staff_or_admin()) with check (public.is_staff_or_admin());
create policy salary_admin_all on public.salary_records for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy salary_employee_read_own on public.salary_records for select to authenticated using (employee_user_id = auth.uid());
create policy complaints_read_own_or_staff on public.complaints for select to authenticated
using (public.is_staff_or_admin() or customer_id = public.my_customer_id());
create policy complaints_create_own on public.complaints for insert to authenticated
with check (created_by = auth.uid() and (public.is_staff_or_admin() or customer_id = public.my_customer_id()));
create policy complaints_staff_update on public.complaints for update to authenticated
using (public.is_staff_or_admin()) with check (public.is_staff_or_admin());
create policy docs_read_own_or_staff on public.shipment_documents for select to authenticated
using (public.is_staff_or_admin() or exists (select 1 from public.shipments s where s.id = shipment_id and s.customer_id = public.my_customer_id()));
create policy docs_staff_manage on public.shipment_documents for all to authenticated
using (public.is_staff_or_admin()) with check (public.is_staff_or_admin());
create policy audit_admin_read on public.audit_logs for select to authenticated using (public.is_admin());
create policy audit_staff_insert on public.audit_logs for insert to authenticated with check (actor_id = auth.uid() and public.is_staff_or_admin());

-- IMPORTANT SETUP NOTE:
-- Promote the first trusted administrator manually from the Supabase SQL editor after signup:
-- update public.profiles set role = 'admin' where id = '<AUTH_USER_UUID>';
-- Never expose service_role credentials in the frontend. Configure Storage buckets and policies
-- separately for POD, invoices, docket PDFs and customer-uploaded documents.
