// Not configured yet. Replace values only after creating the company's Supabase project.
window.MCL_CONFIG = { SUPABASE_URL: '', SUPABASE_ANON_KEY: '' };
