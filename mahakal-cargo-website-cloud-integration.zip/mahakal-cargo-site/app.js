import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const cfg = window.MCL_CONFIG || {};
const configured = /^https:\/\/.+\.supabase\.co$/.test(cfg.SUPABASE_URL || '') && (cfg.SUPABASE_ANON_KEY || '').length > 20;
const supabase = configured ? createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY, { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } }) : null;
let signupMode = false;
let currentUser = null;
let currentProfile = null;

const $ = id => document.getElementById(id);
const setNotice = (message, error=false) => { const el=$('authNotice'); if(el){el.textContent=message;el.style.borderColor=error?'#d44':'#f1dfb5';} };
const statusLabel = s => String(s || '').replaceAll('_',' ').replace(/\b\w/g, c=>c.toUpperCase());

function configWarning(){
  if(!configured){ setNotice('Cloud database is not configured yet. Add the Supabase Project URL and publishable/anon key to config.js after the database migrations are applied.', true); }
}

async function refreshSession(){
  if(!supabase) return;
  const {data:{session}} = await supabase.auth.getSession();
  currentUser = session?.user || null;
  currentProfile = null;
  if(currentUser){
    const {data,error}=await supabase.from('profiles').select('id,full_name,role,customer_id,is_active').eq('id',currentUser.id).single();
    if(!error) currentProfile=data;
    else console.error('Profile lookup failed', error.message);
  }
  const panel=$('sessionPanel');
  if(panel){
    if(currentUser && currentProfile){ panel.classList.remove('hidden'); panel.textContent=`Signed in: ${currentProfile.full_name || currentUser.email} · ${currentProfile.role}.`; }
    else panel.classList.add('hidden');
  }
}

if($('signupToggle')) $('signupToggle').addEventListener('click',()=>{
  signupMode=!signupMode;
  $('signupNameWrap').style.display=signupMode?'block':'none';
  $('signupName').required=signupMode;
  $('loginSubmit').textContent=signupMode?'Create Account':'Sign In';
  $('signupToggle').textContent=signupMode?'Back to Sign In':'Create Customer Account';
  $('loginPassword').autocomplete=signupMode?'new-password':'current-password';
  setNotice(signupMode?'Create a customer account with your email and a password of at least 8 characters. Email confirmation may be required.':'Sign in with your registered email and password.');
});

// Capture-phase handler replaces the starter's local-only demo login.
document.addEventListener('submit', async e=>{
  if(e.target.id!=='loginForm') return;
  e.preventDefault(); e.stopImmediatePropagation();
  if(!supabase){configWarning();return;}
  const email=$('loginEmail').value.trim().toLowerCase();
  const password=$('loginPassword').value;
  const button=$('loginSubmit'); button.disabled=true;
  try{
    if(signupMode){
      const full_name=$('signupName').value.trim();
      const {data,error}=await supabase.auth.signUp({email,password,options:{data:{full_name}}});
      if(error) throw error;
      setNotice(data.session?'Account created. You are signed in.':'Account created. Check your email to confirm registration, then sign in.');
      signupMode=false; $('signupNameWrap').style.display='none'; $('signupName').required=false; button.textContent='Sign In'; $('signupToggle').textContent='Create Customer Account';
      await refreshSession();
    } else {
      const {error}=await supabase.auth.signInWithPassword({email,password}); if(error) throw error;
      await refreshSession();
      if(!currentProfile || !currentProfile.is_active){ await supabase.auth.signOut(); throw new Error('Your account is inactive or its profile is not ready. Contact Mahakal Cargo.'); }
      closeModal('loginModal');
      alert(`Welcome ${currentProfile.full_name || email}. Access role: ${currentProfile.role}.`);
    }
  }catch(err){setNotice(err.message || 'Authentication failed.',true);}finally{button.disabled=false;}
},true);

// A role chosen in the old UI is never trusted; access comes only from the database profile.
// Customer bookings create pickup-request status and zero financial values via the database trigger.
document.addEventListener('submit', async e=>{
  if(e.target.id!=='bookingForm') return;
  e.preventDefault(); e.stopImmediatePropagation();
  if(!supabase){alert('Cloud booking is not configured yet. Please call 01169655510.');return;}
  await refreshSession();
  if(!currentUser || !currentProfile){openModal('loginModal');setNotice('Please sign in or create a customer account before submitting a booking.');return;}
  const d=Object.fromEntries(new FormData(e.target));
  const serviceMap={'Road Cargo':'road','Air Cargo':'air','Railway Cargo':'railway','PTL / FTL':'ptl','Door-to-Door':'door_to_door','Packers & Movers':'packers_movers'};
  const [sender_city,...senderPin]=String(d.origin||'').split(/\s+(?=\d{6}$)/);
  const [receiver_city,...receiverPin]=String(d.destination||'').split(/\s+(?=\d{6}$)/);
  const payload={created_by:currentUser.id,customer_id:currentProfile.role==='customer'?currentProfile.customer_id:null, sender_name:d.sender,sender_mobile:d.senderMobile,sender_city:sender_city.trim(),sender_pincode:senderPin.join('').trim()||null,receiver_name:d.receiver,receiver_mobile:d.receiverMobile||null,receiver_city:receiver_city.trim(),receiver_pincode:receiverPin.join('').trim()||null,service_type:serviceMap[d.mode]||'road',actual_weight_kg:Number(d.weight||0),goods_description:d.details||null,package_count:1};
  if(currentProfile.role==='customer' && !currentProfile.customer_id){alert('Customer profile is not linked. Contact the office before booking.');return;}
  const {data,error}=await supabase.from('shipments').insert(payload).select('docket_no,status').single();
  if(error){alert('Booking could not be submitted: '+error.message);return;}
  closeModal('bookingModal');e.target.reset();
  alert(`Booking request received. Docket: ${data.docket_no}. Status: ${statusLabel(data.status)}. Save this docket number for tracking.`);
},true);

// Public tracking uses the restricted SQL function, never direct anonymous table access.
window.trackShipment=async function(){
  const docket=$('trackInput').value.trim().toUpperCase(); const out=$('trackResult');
  if(!docket){out.textContent='Please enter your docket / LR number.';return;}
  if(!supabase){out.textContent='Live tracking is not configured yet. Please call 01169655510.';return;}
  out.textContent='Checking shipment status…';
  const {data,error}=await supabase.rpc('track_shipment',{p_docket_no:docket});
  if(error){out.textContent='Tracking service is temporarily unavailable. Please call 01169655510.';console.error(error);return;}
  const s=data?.[0];
  if(!s){out.textContent='No tracking record found. Please verify your docket number or call 01169655510.';return;}
  const events=Array.isArray(s.events)?s.events:[];
  const safe=(v)=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  out.innerHTML=`<div style="border-top:1px solid #eee;padding-top:12px"><b>${safe(s.docket_no)}</b><br>${safe(s.origin_city)} → ${safe(s.destination_city)}<br><b style="color:var(--green)">${safe(statusLabel(s.current_status))}</b><div style="margin-top:10px">${events.map(ev=>`<div style="padding:7px 0;border-top:1px solid #eee"><b>${safe(statusLabel(ev.status))}</b><br><span class="muted">${safe(ev.location||'')} · ${safe(new Date(ev.event_time).toLocaleString('en-IN'))}</span>${ev.remarks?`<br>${safe(ev.remarks)}`:''}</div>`).join('')||'<span class="muted">No public scan events recorded yet.</span>'}</div></div>`;
};

if(supabase){supabase.auth.onAuthStateChange(()=>{refreshSession();});refreshSession();}else configWarning();
