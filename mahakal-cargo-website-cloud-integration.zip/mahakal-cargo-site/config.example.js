// Copy this file to config.js and fill in your Supabase project values.
// The publishable/anon key is intended for browser use with RLS enabled.
// NEVER put the service_role key or database password in this file.
window.MCL_CONFIG = {
  SUPABASE_URL: 'https://YOUR-PROJECT.supabase.co',
  SUPABASE_ANON_KEY: 'YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY'
};
