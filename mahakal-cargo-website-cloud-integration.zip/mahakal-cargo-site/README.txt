MAHAKAL CARGO LOGISTICS WEBSITE - STARTER PREVIEW

Files:
- index.html: responsive public website with booking enquiry UI, tracking UI, login UI and admin dashboard visual preview.

IMPORTANT:
This is a front-end starter preview, not a production-ready live courier platform. The booking form currently stores a demo enquiry in the visitor's browser only. Login is intentionally not connected and no live shipment records, SMS, WhatsApp, payments, invoices or POD are processed.

To make mahakalcargo.com fully operational, the next phase must include:
1. Hosting and DNS access for mahakalcargo.com.
2. Supabase (or equivalent) project and secure server-side configuration.
3. Database tables for users, roles, customers, branches, bookings, docket events, rates, invoices, payments, expenses, drivers, trips, delivery proofs and audit logs.
4. Secure Admin / Employee / Customer authentication and row-level access policies.
5. Server-side docket numbering, rate calculation, GST invoice and PDF generation.
6. Tracking event API and public tracking endpoint.
7. Email/SMS/WhatsApp provider credentials if notifications are required.
8. Backup, audit logging, testing and production deployment.

Do not publish this preview as a live booking or tracking service until backend integration and security testing are complete.
